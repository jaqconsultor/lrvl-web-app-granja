export default {
  name: 'contactsList',
};
